/*
 * Procedural Minesweeper
 * 
 * Jose Sepulveda
 * 
 * 6/11/15
 * 
 * Linux Mint 17 Eclipse Java SE 1.8
 * 
 * This is a revision of my lowest scoring hw, all the issues that I was marked down on are fixed.
 * 
 * 
 * 
 * 
 * 
 * 
 */

package HW2_Updated;

import java.util.*;
public class Game {
	private static final int min = 5, max = 15;
	public static Scanner scanner = new Scanner( System.in );
	static public void main(String [] args){
		int rows, cols, numOfSpots;
		rows = InputMethods.readInt("Enter the # of Rows", min, max);
		cols = InputMethods.readInt("Enter the # of Cols", min, max);
		boolean [][] compGrid, playGrid, matchGrid;
		
		compGrid = allocateGrid(rows, cols);
		playGrid = allocateGrid(rows, cols);
		matchGrid = allocateGrid(rows, cols);
		boolean b = true;
	while(b){

		numOfSpots = InputMethods.readInt("Enter # of spots to set", rows, (rows*cols)/2); 
		compGrid = setRandomValues(compGrid, numOfSpots);
		setInputValues(playGrid, numOfSpots);
		matchGrid = compareGrid(playGrid, compGrid, matchGrid);
		displayGrid("Player Grid:\n", "X", playGrid);
		displayGrid("Comp Grid:\n", "X", compGrid);
		displayGrid("Match Grid:\n", "X", matchGrid);
		b = InputMethods.wantsToRepeat();
	};
		
		
	}

	static public boolean[][] initGrid(boolean [][] grid){
		for(int i = 0; i < grid.length; i++){
			for(int j = 0; j < grid[0].length; j++){
				grid[i][j] = false;
			}
		}
		return grid;
		
	}
	static public void displayGrid(String prompt, String mine, boolean[][] grid){
		System.out.println(prompt);
		for(int i=0; i < grid.length; i++){
			for(int j = 0; j < grid[0].length; j++){
				System.out.printf("|");
				if(grid[i][j] == true){
					System.out.printf(mine);
				} else {
					System.out.printf(" ");
				}
			}
			System.out.printf("|\n");
		}
	}
	static public boolean[][] compareGrid(boolean[][] grid,boolean[][] grid2, boolean[][] grid3){
		grid3 = initGrid(grid3);
		for(int i=0; i < grid.length; i++)
			for(int j = 0; j < grid[0].length; j++){
				if(grid[i][j] == true && grid2[i][j] == true){
					grid3[i][j] = true;
				}
			}
		return grid3;
	}
	static public void setInputValues(boolean[][] grid, int num){
		grid = initGrid(grid);
		int row, col;
		int counter = 1;
		while(counter <= num){
			row = InputMethods.readInt("Enter row number for mine: " + counter, 0, grid.length - 1);
			col = InputMethods.readInt("Enter col number for mine: " + counter, 0, grid[0].length - 1);
			if(!grid[row][col]){
				grid[row][col] = true;
				counter++;
			}else{
				System.out.println("Sorry already chosen.\n");
			}

		}
		
	}
	static public boolean[][] allocateGrid(int r, int c){
		boolean [][] grid;
		grid = new boolean[r][c];
		return grid;
		
	}
	static public boolean[][] setRandomValues(boolean [][] grid, int num){
		grid = initGrid(grid);
		Random rand = new Random();
		int rows = grid.length;
		int cols = grid[0].length;
		int temp1, temp2;
		int counter = 1;
		while(counter <= num){
			temp1 = rand.nextInt(rows);
			temp2 = rand.nextInt(cols);
			if(!(grid[temp1][temp2] == true)){
				grid[temp1][temp2] = true;
				counter++;
				//cheater code
				//System.out.println(temp1 +" "+ temp2);
			}

		}

		return grid;
		
	}
	
	
}
/*
Enter the # of Rows6
Enter the # of Cols6
Enter # of spots to set6
Enter row number for mine: 16
Input out of range, must be >= 0 and <= 5
Enter row number for mine: 10
Enter col number for mine: 11
Enter row number for mine: 25
Enter col number for mine: 26
Input out of range, must be >= 0 and <= 5
Enter col number for mine: 21
Enter row number for mine: 32
Enter col number for mine: 32
Enter row number for mine: 41
Enter col number for mine: 44
Enter row number for mine: 54
Enter col number for mine: 54
Enter row number for mine: 64
Enter col number for mine: 64
Sorry already chosen.

Enter row number for mine: 644
Input out of range, must be >= 0 and <= 5
Enter row number for mine: 65
Enter col number for mine: 66
Input out of range, must be >= 0 and <= 5
Enter col number for mine: 68
Input out of range, must be >= 0 and <= 5
Enter col number for mine: 62
Player Grid:

| |X| | | | |
| | | | |X| |
| | |X| | | |
| | | | | | |
| | | | |X| |
| |X|X| | | |
Comp Grid:

|X| | | |X|X|
| | | | | | |
| | | | | | |
| | | | |X| |
| | | |X| |X|
| | | | | | |
Match Grid:

| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
Do you want to repeat? (y or Y)
y
Enter # of spots to set4
Input out of range, must be >= 6 and <= 18
Enter # of spots to set10
Enter row number for mine: 11
Enter col number for mine: 12
Enter row number for mine: 26
Input out of range, must be >= 0 and <= 5
Enter row number for mine: 21
Enter col number for mine: 22
Sorry already chosen.

Enter row number for mine: 23
Enter col number for mine: 20
Enter row number for mine: 31
Enter col number for mine: 32
Sorry already chosen.

Enter row number for mine: 31
Enter col number for mine: 32
Sorry already chosen.

Enter row number for mine: 33
Enter col number for mine: 34
Enter row number for mine: 45
Enter col number for mine: 46
Input out of range, must be >= 0 and <= 5
Enter col number for mine: 42
Enter row number for mine: 50
Enter col number for mine: 51
Enter row number for mine: 63
Enter col number for mine: 64
Sorry already chosen.

Enter row number for mine: 62
Enter col number for mine: 61
Enter row number for mine: 75
Enter col number for mine: 73
Enter row number for mine: 80
Enter col number for mine: 84
Enter row number for mine: 966
Input out of range, must be >= 0 and <= 5
Enter row number for mine: 93
Enter col number for mine: 91
Enter row number for mine: 100
Enter col number for mine: 102
Player Grid:

| |X|X| |X| |
| | |X| | | |
| |X| | | | |
|X|X| | |X| |
| | | | | | |
| | |X|X| | |
Comp Grid:

|X| | | | | |
| | | | | | |
| |X| | |X| |
| | | | | | |
|X|X|X|X| | |
| |X|X| | |X|
Match Grid:

| | | | | | |
| | | | | | |
| |X| | | | |
| | | | | | |
| | | | | | |
| | |X| | | |
Do you want to repeat? (y or Y)
y
Enter # of spots to set6
Enter row number for mine: 10
Enter col number for mine: 10
Enter row number for mine: 21
Enter col number for mine: 21
Enter row number for mine: 32
Enter col number for mine: 32
Enter row number for mine: 43
Enter col number for mine: 43
Enter row number for mine: 54
Enter col number for mine: 54
Enter row number for mine: 65
Enter col number for mine: 65
Player Grid:

|X| | | | | |
| |X| | | | |
| | |X| | | |
| | | |X| | |
| | | | |X| |
| | | | | |X|
Comp Grid:

| | | | | | |
|X| |X| | | |
|X| | | | | |
| | | | | |X|
| | | | |X| |
| | | | |X| |
Match Grid:

| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | |X| |
| | | | | | |
Do you want to repeat? (y or Y)
n


 */
