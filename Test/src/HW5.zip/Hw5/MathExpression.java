package Hw5;
public interface MathExpression {
	public double evaluate();
}
